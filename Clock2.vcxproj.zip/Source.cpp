//============================================================================
// Name        : Clock2.cpp
// Author      : Carlos Stockl
// SNHU Class  : CS210-T2754
// Copyright   : NONE
// Description : 12 AND 24-HOURS CLOCK IN C++
//============================================================================
#include <iostream>
using namespace std;

int menuInput; //CLOCK MANU VARIABLE 
bool exitChecker = true; //IF USER CHOSE 4 THIS PROGRAM WILL EXIT
int i = 0; //FOR TRACK IF AM/PM BY COMPARINGS HORS 12/24 HOURS
int hr24 = 0; //24 HOURS CLOCK  
int hr = 12; //12 HOURS CLOCK 
int minute = 0; //MINUTES FOR BOTH 12 AND 24 HR CLOCK
int sec = 0; //SECONDS FOR BOTH 12 AND 24 HR CLOCK


// DISPLAY CLOCK
void printTime() {
	
	cout << "###########################  ###########################" << endl;
	cout << "#       12-Hour Clock     #  #        24-Hour Clock    #" << endl;
	cout << "#       "; if (hr < 10) cout << "0"; cout << hr << ":"; if (minute < 10) cout << "0"; cout << minute << ":"; if (sec < 10) cout << "0"; cout << sec << " "; if (i == 0)cout << "AM"; else if (i == 1)cout << "PM"; cout << "       *  *        "; if (hr24 < 10) cout << "0"; cout << hr24 << ":"; if (minute < 10) cout << "0"; cout << minute << ":"; if (sec < 10) cout << "0"; cout << sec << "         *" << endl;
	cout << "###########################  ###########################" << endl;
}


//DISPLAY MENU OPTIONS
void displayMenu() {

	cout << "###########################\n";
	cout << "# 1 - Add One Hour        #\n";
	cout << "# 2 - Add One Minute      #\n";
	cout << "# 3 - Add One Second      #\n";
	cout << "# 4 - Exit Program        #\n";
	cout << "###########################\n";
}
//USER INPUT AND ACTION 
void menuAction() {
	switch (menuInput) {
	case 1:
		hr24++;
		hr++;
		if (hr24 == 24) {
			hr24 = 0;
		}
		if (hr24 < 12) {
			i = 0;
		}
		if (hr == 13) {
			hr = 1;
		}
		if (hr24 >= 12) {
			i = 1;
		}
		break;
	case 2:
		minute++;
		if (minute == 60) {
			hr++;
			hr24++;
			minute = 0;
			if (hr24 < 12) {
				i = 0;
			}
			if (hr24 >= 12) {
				i = 1;
			}
			if (hr == 13) {
				hr = 1;
			}
			if (hr24 == 24) {
				hr24 = 0;
			}
		}
		break;
	case 3:
		sec++;
		if (sec == 60) {
			minute++;
			sec = 0;
			if (minute == 60) {
				hr++;
				hr24++;
				minute = 0;
				if (hr24 < 12) {
					i = 0;
				}
				if (hr == 13) {
					hr = 1;
				}
				if (hr24 >= 12) {
					i = 1;
				}
				if (hr24 == 24) {
					hr24 = 0;
				}
			}
		}
		break;
	case 4:
		cout << "Exiting Clock Program" << endl;
		exitChecker = false;
		break;
	default:
		cout << "Unexpected Input Received. Please Enter A Valid Menu Item." << endl;
	}

}
//PRINTS TIME, DISPLAYS MENU, TAKE USER IMPUT/ USER HAS THE OPTION TO EXITS
int main() {

	while (exitChecker) {

		printTime();
		displayMenu();
		cin >> menuInput;
		menuAction();
	}
	return 0;
}